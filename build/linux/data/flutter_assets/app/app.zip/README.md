# Wavio-Player
#### A small and simply music player in Material Design style. #
Applicaton writing in Python with flet framework.

For a building app on a Windows run in terminal:

  ```pyinstaller --onefile main.py```

On a linux:

  ```pyinstaller --onedir main.py```

For running app on Windows, go to `dist` directory and run `main.exe`. On a Linux distrbutions, go to `dist/main` and run in a terminal: `./main`.
